<head><link rel="stylesheet" href="navstyle.css"></head>
<div class="topnav">
  <a href="profile.php">Profile</a>
  <a href="vehicle.php">My Vehicles</a>
  <a href="service.php">Service</a>
  <a class="active" href="history.php">History</a>
</div>

<?php
   session_start();
   $link=mysqli_connect("localhost","root","","scdb");
   $userid=$_SESSION['userid'];
   $query="select s_type, f_type, v_no, v_model, b_date, sc_loc, e_name, b_amt, v_insurance from spares, fault, ser_center, vehicle, employees, bill where bill.c_id='$userid' and bill.e_id=employees.e_id and bill.s_id=spares.s_id and bill.f_id=fault.f_id and bill.v_id=vehicle.v_id and bill.sc_id=ser_center.sc_id";
   if ($result=mysqli_query($link,$query)){
    if (mysqli_num_rows($result)>0){
        echo "<style> td {padding:10px;} th {padding:15px;} </style>";
        echo "<table border=1 style= 'margin-top: 50px; margin-left: 50px;'>";
        echo "<tr>";
        echo "<th>Service</th>";
        echo "<th>Fault</th>";
        echo "<th>Vehicle No.</th>";
        echo "<th>Model</th>";
        echo "<th>Date</th>";
        echo "<th>Service Centre Branch</th>";
        echo "<th>Mechanic</th>";
        echo "<th>Bill Amount</th>";
        echo "<th>Covered in Insurance</th>";
        echo "</tr>";
        while ($row=mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$row['s_type']."</td>";
            echo "<td>".$row['f_type']."</td>";
            echo "<td>".$row['v_no']."</td>";
            echo "<td>".$row['v_model']."</td>";
            echo "<td>".$row['b_date']."</td>";
            echo "<td>".$row['sc_loc']."</td>";
            echo "<td>".$row['e_name']."</td>";
            echo "<td>".$row['b_amt']."</td>";
            echo "<td>".$row['v_insurance']."</td>";
            echo "</tr>";
        } 
        mysqli_free_result($result);
    }
   }
   mysqli_close($link);
?>