<?php
session_start();
$link=mysqli_connect("localhost","root","","scdb");
$_SESSION['userid']=$_POST['id'];
$password=$_POST['pwd'];
$query="SELECT * FROM cus WHERE c_id='$_SESSION[userid]' and password='$password'";
$result=mysqli_query($link,$query);
$count=mysqli_num_rows($result);
if ($count>0){
    header("Location: profile.php");
}
else{
    echo "Incorrect username or password! Try again!";
}
mysqli_close($link);
?>