<head><link rel="stylesheet" href="navstyle.css"></head>
<div class="topnav">
  <a class="active" href="profile.php">Profile</a>
  <a href="vehicle.php">My Vehicles</a>
  <a href="service.php">Service</a>
  <a href="history.php">History</a>
</div>

<?php
   session_start();
   $link=mysqli_connect("localhost","root","","scdb");
   $userid=$_SESSION['userid'];
   $query="SELECT * FROM cus WHERE c_id='$userid'";
   if ($result=mysqli_query($link,$query)){
    if($row=mysqli_fetch_array($result)){
        echo "<style> td {padding:10px;} </style>";
        echo "<table border=1 style= 'margin-top: 50px; margin-left: 50px; margin-bottom: 50px;'>";
        echo "<tr>";
        echo "<td>ID</td>";
        echo "<td>".$row['c_id']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Name</td>";
        echo "<td>".$row['c_name']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>License No.</td>";
        echo "<td>".$row['c_license_no']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Phone No.</td>";
        echo "<td>".$row['c_ph_no']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Password</td>";
        echo "<td>".$row['password']."</td>";
        echo "</tr>";
        echo "</table>";
        mysqli_free_result($result);
    }
   }
   mysqli_close($link);
?>

<style>.submit {
    margin-top: 40px;
    margin-bottom: 20px;
    background: #d4af7a;
    text-transform: uppercase;}
    label span {
    font-size: 12px;
    color: #d4af7a;
    text-transform: uppercase;}
    input {
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center;}
    button {
    
    margin: 0 auto;
    width: 160px;
    height: 36px;
    border-radius: 30px;
    color: #fff;
    font-size: 15px;
    cursor: pointer;
}
</style>
<div style="margin-left: 50px;">
   <form action="profileup.php" method="post">
                <label>
                    <span>New Name</span>
                    <input type="text" name="name"/>
                </label><br><br>
                <label>
                    <span>New Phone Number</span>
                    <input type="number" name="ph"/>
                </label><br><br>
                <label>
                    <span>New Password</span>
                    <input type="text" name="pwd"/>
                </label><br>
                <button type="submit" class="submit">Update</button>
   </form>
</div>