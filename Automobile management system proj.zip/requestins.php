<?php
$link=mysqli_connect("localhost","root","","scdb");
$query="UPDATE request set r_date='$_POST[date]', r_time='$_POST[time]' where r_id='$_POST[id]'";
if(mysqli_query($link,$query)){
    echo"request accepted";
}
mysqli_close($link);
?>