<?php
session_start();
$link=mysqli_connect("localhost","root","","scdb");
$userid=$_SESSION['userid'];
$query="INSERT into vehicle values('$_POST[id]','$_POST[no]','$_POST[mod]','$_POST[ins]','$userid','$_POST[scid]','$_POST[scid]')";
mysqli_query($link,$query);
header("Location: vehicle.php");
mysqli_close($link);
?>