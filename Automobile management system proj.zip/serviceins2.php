<?php
session_start();
$link=mysqli_connect("localhost","root","","scdb");
$userid=$_SESSION['userid'];
$fault=$_SESSION['fault'];
$vid=$_SESSION['vid'];
$sid=$_SESSION['sid'];
$query5="select r_date, r_time from request where request.f_id=(select max(f_id) from fault)";
   if ($result5=mysqli_query($link,$query5)){
    if($row=mysqli_fetch_array($result5)){
        echo "<style> td {padding:10px;} th {padding:15px;} tfoot {
            background-color: #3f87a6;
            color: #fff;
        }</style>";
        echo "<center>";
        echo "<table border=1 style= 'margin-top: 20px;'>";
        echo "<tr>";
        echo "<th>Appointment Date</th>";
        echo "<td>".$row['r_date']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>Appoinment Time</th>";
        echo "<td>".$row['r_time']."</td>";
        echo "</tr>";
        echo "</table>";
        echo "</center>";
        mysqli_free_result($result5);
        } } 
    $query="select b_no, b_date,curtime(), sc_loc, v_id, c_id, s_type, b_amt from bill, ser_center, spares where b_no=(select max(b_no) from bill) and bill.sc_id=ser_center.sc_id and bill.s_id=spares.s_id";
   if ($result=mysqli_query($link,$query)){
    if($row=mysqli_fetch_array($result)){
        echo "<style> td {padding:10px;} th {padding:15px;} tfoot {
            background-color: #3f87a6;
            color: #fff;
        }</style>";
        echo "<center>";
        echo "<h1 style='color:#3f87a6; margin-top:20px;'>Bill</h1>";
        echo "<table border=1 style= 'margin-top: 20px;'>";
        echo "<tr>";
        echo "<th>Bill No.</th>";
        echo "<td>".$row['b_no']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>Date</th>";
        echo "<td>".$row['b_date']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>Time</th>";
        echo "<td>".$row['curtime()']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>Branch</th>";
        echo "<td>".$row['sc_loc']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>Vehicle ID</th>";
        echo "<td>".$row['v_id']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>User ID</th>";
        echo "<td>".$row['c_id']."</td>";
        echo "</tr>";
        echo "<tfoot>";
        echo "<tr>";
        echo "<th>Service</th>";
        echo "<td>".$row['s_type']."</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>Amount</th>";
        echo "<td>".$row['b_amt']."</td>";
        echo "</tr>";
        echo "</tfoot>";
        echo "</table>";
        echo "</center>";
        mysqli_free_result($result);
        }  
    }
    ?>
<style>.submit {
    margin-top: 0px;
    margin-bottom: 20px;
    background: #3f87a6;
    text-transform: uppercase;}
    button {
    
    margin: 0 auto;
    width: 160px;
    height: 36px;
    border-radius: 30px;
    color: #fff;
    font-size: 15px;
    cursor: pointer;
}
</style>
<div style="margin-top:50px;">
   <form action="trans.php" method="post">
                <center>
                <button type="submit" class="submit">Pay</button>
                </center>
   </form>
</div>
    