<?php
session_start();
$link=mysqli_connect("localhost","root","","scdb");
$query1="select r_id, v_no, v_model,s_type, sc_loc from vehicle, ser_center,request,spares,fault where request.f_id=fault.f_id and fault.s_id=spares.s_id and fault.v_id=vehicle.v_id and vehicle.sc_id=ser_center.sc_id";
   if ($result=mysqli_query($link,$query1)){
    if (mysqli_num_rows($result)>0){
        echo "<style> td {padding:10px;} th {padding:15px;} </style>";
        echo "<table border=1 style= 'margin-top: 50px; margin-left: 50px; margin-bottom: 50px;'>";
        echo "<tr>";
        echo "<th>Request ID</th>";
        echo "<th>Vehicle No.</th>";
        echo "<th>Make and Model</th>";
        echo "<th>Service Type</th>";
        echo "<th>Service Centre Branch</th>";
        echo "</tr>";
        while ($row=mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$row['r_id']."</td>";
            echo "<td>".$row['v_no']."</td>";
            echo "<td>".$row['v_model']."</td>";
            echo "<td>".$row['s_type']."</td>";
            echo "<td>".$row['sc_loc']."</td>";
            echo "</tr>";
        } 
        echo "</table>";
        mysqli_free_result($result);
    }
   }
   mysqli_close($link);
?>
<style>.submit {
    margin-top: 40px;
    margin-bottom: 20px;
    background: #d4af7a;
    text-transform: uppercase;}
    label span {
    font-size: 12px;
    color: #d4af7a;
    text-transform: uppercase;}
    input {
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center;}
    select{
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center;
    }
    option {
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center; 
    }
    button {
    
    margin: 0 auto;
    width: 160px;
    height: 36px;
    border-radius: 30px;
    color: #fff;
    font-size: 15px;
    cursor: pointer;
}
</style>
<div style="margin-left: 50px; margin-top: 50px;">
   <form action="requestins.php" method="post">
                <label>
                    <span>Request ID</span>
                    <input type="number" name="id"/>
                </label><br>
                <label>
                    <span>Request Date</span>
                    <input type="date" name="date"/>
                </label><br>
                <label>
                    <span>Time</span>
                    <input type="time" name="time"/>
                </label><br>
                <button type="submit" class="submit">Accept</button><br><br>
   </form>
</div>
