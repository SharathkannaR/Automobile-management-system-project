<head><link rel="stylesheet" href="navstyle.css"></head>
<div class="topnav">
  <a href="profile.php">Profile</a>
  <a class="active" href="vehicle.php">My Vehicles</a>
  <a href="service.php">Service</a>
  <a href="history.php">History</a>
</div>

<?php
   session_start();
   $link=mysqli_connect("localhost","root","","scdb");
   $userid=$_SESSION['userid'];
   $query="select v_id, v_no, v_model, v_insurance, sc_loc from vehicle, ser_center where c_id='$userid' and vehicle.sc_id=ser_center.sc_id";
   if ($result=mysqli_query($link,$query)){
    if (mysqli_num_rows($result)>0){
        echo "<style> td {padding:10px;} th {padding:15px;} </style>";
        echo "<table border=1 style= 'margin-top: 50px; margin-left: 50px; margin-bottom: 50px;'>";
        echo "<tr>";
        echo "<th>Vehicle ID</th>";
        echo "<th>Vehicle No.</th>";
        echo "<th>Make and Model</th>";
        echo "<th>Insurance</th>";
        echo "<th>Service Centre Branch</th>";
        echo "</tr>";
        while ($row=mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$row['v_id']."</td>";
            echo "<td>".$row['v_no']."</td>";
            echo "<td>".$row['v_model']."</td>";
            echo "<td>".$row['v_insurance']."</td>";
            echo "<td>".$row['sc_loc']."</td>";
            echo "</tr>";
        } 
        echo "</table>";
        mysqli_free_result($result);
    }
   }
   mysqli_close($link);
?>

<style>.submit {
    margin-top: 40px;
    margin-bottom: 20px;
    background: #d4af7a;
    text-transform: uppercase;}
    label span {
    font-size: 12px;
    color: #d4af7a;
    text-transform: uppercase;}
    input {
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center;}
    select{
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center;
    }
    option {
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center; 
    }
    button {
    
    margin: 0 auto;
    width: 160px;
    height: 36px;
    border-radius: 30px;
    color: #fff;
    font-size: 15px;
    cursor: pointer;
}
</style>
<div style="margin-left: 50px; margin-top: 50px;">
   <form action="vehicleins.php" method="post">
                <label>
                    <span>ID</span>
                    <input type="number" name="id"/>
                </label><br><br>
                <label>
                    <span>Vehicle No.</span>
                    <input type="text" name="no"/>
                </label><br><br>
                <label>
                    <span>Make and Model</span>
                    <input type="text" name="mod"/>
                </label><br><br>
                <label>
                    <span>Insurance</span>
                    <input type="text" name="ins"/>
                </label><br><br>
                <label>
                    <span>Service Centre Branch</span><br>
                    <select name="scid">
                        <option value=1>Avadi</option>
                        <option value=2>Sriperumbudhur</option>
                        <option value=3>Pallavaram</option>
                        <option value=4>ECR</option>
                        <option value=5>Anna Nagar</option>
                    </select>
                </label><br>
                <button type="submit" class="submit">Add</button><br><br>
   </form>
</div>
<div style="margin-left: 50px;">
   <form action="vehicledel.php" method="post">
                <label>
                    <span>ID</span>
                    <input type="number" name="id"/>
                </label><br>
                <button type="submit" class="submit">Remove</button>
   </form>
</div>