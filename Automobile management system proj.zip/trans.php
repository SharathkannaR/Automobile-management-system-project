

<?php
session_start();
$link=mysqli_connect("localhost","root","","scdb");
$query="DELETE from request";
mysqli_query($link,$query);
mysqli_close($link);
?>

<html>
    <head>
        <style>
            a:link {
              color: green;
              background-color: transparent;
              text-decoration: none;
            }
            a:visited {
              color: green;
              background-color: transparent;
              text-decoration: none;
            }
            a:hover {
              color: grey;
              background-color: transparent;
              text-decoration: underline;
            }
            </style>
    </head>
    <body>
        <center>
            <h1 style="color:green; margin-top: 200px;">Transaction Status: Success</h1><img src="https://icon-library.com/images/successful-icon/successful-icon-10.jpg" height="100" width="100"/><br>
            <div style="float:right; margin-top:30%;">
                <a href="history.php">Back to Profile</a>
            </div>
        </center>
    </body>
</html>