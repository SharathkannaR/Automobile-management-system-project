<?php
                       session_start();
                       $link=mysqli_connect("localhost","root","","scdb");
                       $userid=$_SESSION['userid'];
                       $_SESSION['vid']=$_POST['id'];
                       $_SESSION['fault']=$_POST['ft'];
                       $_SESSION['sid']=$_POST['sid'];
                       $query="select e_id, e_name from employees where e_desg='mechanic' and sc_id=(select sc_id from vehicle where v_id='$_POST[id]')";
                       if ($result=mysqli_query($link,$query)){
                        if (mysqli_num_rows($result)>0){
                            echo "<h2 style='margin-left:50px; color:#d4af7a;'>Available Employees</h2>";
                            echo "<style> td {padding:10px;} th {padding:15px;} </style>";
                            echo "<table border=1 style= 'margin-top: 20px; margin-left: 50px; margin-bottom: 50px;'>";
                            echo "<tr>";
                            echo "<th>Employee ID</th>";
                            echo "<th>Mechanic Name</th>";
                            echo "</tr>";
                            while ($row=mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td>".$row['e_id']."</td>";
                                echo "<td>".$row['e_name']."</td>";
                                echo "</tr>";
                            } 
                            echo "</table>";
                            mysqli_free_result($result);
                        }
                       }
                       mysqli_close($link);
                ?>

<style>.submit {
    margin-top: 40px;
    margin-bottom: 20px;
    background: #d4af7a;
    text-transform: uppercase;}
    label span {
    font-size: 12px;
    color: #d4af7a;
    text-transform: uppercase;}
    input {
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center;}
    button {
    
    margin: 0 auto;
    width: 160px;
    height: 36px;
    border-radius: 30px;
    color: #fff;
    font-size: 15px;
    cursor: pointer;
}
</style>
<div style="margin-left: 50px;">
   <form action="serviceins.php" method="post">
                <label>
                    <span>Employee ID</span>
                    <input type="text" name="eid"/>
                </label><br>
                <button type="submit" class="submit">Submit</button>
   </form>
</div>


