<?php
session_start();
$link=mysqli_connect("localhost","root","","scdb");
$userid=$_SESSION['userid'];
$query="UPDATE cus set c_name='$_POST[name]', c_ph_no='$_POST[ph]', password='$_POST[pwd]' where c_id='$userid'";
mysqli_query($link,$query);
header("Location: profile.php");
mysqli_close($link);
?>