<?php
session_start();
$link=mysqli_connect("localhost","root","","scdb");
$userid=$_SESSION['userid'];
$fault=$_SESSION['fault'];
$vid=$_SESSION['vid'];
$sid=$_SESSION['sid'];
$_SESSION['eid']=$_POST['eid'];
$query1="insert into fault(f_type,repair_date,s_id,v_id,e_id) values('$fault',curdate(),'$sid','$vid','$_POST[eid]')";
mysqli_query($link,$query1);

$query2="insert into bill(b_date,b_amt,sc_id,f_id,s_id,v_id,e_id,c_id) values(curdate(),(select s_price from spares where s_id='$sid'),(select sc_id from vehicle where v_id='$vid'),(select max(f_id) from fault),'$sid','$vid','$_POST[eid]','$userid')";
mysqli_query($link,$query2);

$query3="insert into transaction(b_no,t_status) values((select max(b_no) from bill), 'success')"; 
mysqli_query($link,$query3);

$query5="insert into request(f_id) value((select max(f_id) from fault))"; 
mysqli_query($link,$query5);

$query4="select r_date from request where request.f_id=(select max(f_id) from fault) and r_date>'0000-00-00'";
if($result4=mysqli_query($link,$query4)){
    if(mysqli_num_rows($result4)==0){
        echo "<center><img src='https://img.freepik.com/premium-vector/system-software-update-upgrade-concept-loading-process-screen-vector-illustration_175838-2182.jpg?w=2000' heigjt='300' width='300'/></center>";
    }  
}


mysqli_close($link);
?>

<style>.submit {
    margin-top: 0px;
    margin-bottom: 20px;
    background: #3f87a6;
    text-transform: uppercase;}
    button {
    
    margin: 0 auto;
    width: 160px;
    height: 36px;
    border-radius: 30px;
    color: #fff;
    font-size: 15px;
    cursor: pointer;
}
</style>
<div style="margin-top:50px;">
   <form action="serviceins2.php" method="post">
                <center>
                <button type="submit" class="submit">Next</button>
                </center>
   </form>
</div>


