<?php
$link=mysqli_connect("localhost","root","","scdb");
$query="INSERT INTO cus VALUES ($_POST[id], '$_POST[name]', '$_POST[lno]', $_POST[ph], '$_POST[pwd]')";
mysqli_query($link,$query);
mysqli_close($link);
header("Location: homepage.html");
?>