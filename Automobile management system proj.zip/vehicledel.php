<?php
session_start();
$link=mysqli_connect("localhost","root","","scdb");
$userid=$_SESSION['userid'];
$query="DELETE from vehicle where v_id='$_POST[id]'";
mysqli_query($link,$query);
header("Location: vehicle.php");
mysqli_close($link);
?>