<?php
if ($_POST['adus']=='admin' && $_POST['adpwd']=='admin'){
    header("Location: request.php");
}
else{
    echo "Incorrect username or password!";
}
?>