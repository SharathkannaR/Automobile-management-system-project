<head><link rel="stylesheet" href="navstyle.css"></head>
<div class="topnav">
  <a href="profile.php">Profile</a>
  <a href="vehicle.php">My Vehicles</a>
  <a class="active" href="service.php">Service</a>
  <a href="history.php">History</a>
</div>

<style>.submit {
    margin-top: 40px;
    margin-bottom: 20px;
    background: #d4af7a;
    text-transform: uppercase;}
    label span {
    font-size: 12px;
    color: #d4af7a;
    text-transform: uppercase;}
    input {
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center;}
    select{
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center;
    }
    option {
    display: block;
    width: 30%;
    margin-top: 5px;
    padding-bottom: 5px;
    font-size: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    text-align: center; 
    }
    button {
    
    margin: 0 auto;
    width: 160px;
    height: 36px;
    border-radius: 30px;
    color: #fff;
    font-size: 15px;
    cursor: pointer;
}
</style>
<div style="margin-left: 50px; margin-top:50px;">
   <form action="next.php" method="post">
                <label>
                    <span>Vehicle ID</span>
                    <input type="number" name="id"/>
                </label><br><br>
                <label>
                    <span>Fault</span>
                    <input type="text" name="ft" placeholder="what is wrong with your vehicle"/>
                </label><br><br>
                <label>
                    <span>Service Type</span><br>
                    <select name="sid">
                        <option value=1>brake related</option>
                        <option value=2>engine oriented</option>
                        <option value=3>silencer cleaning</option>
                        <option value=4>bonnet related</option>
                        <option value=5>tyre related</option>
                        <option value=6>parts replacement</option>
                        <option value=7>general service</option>
                    </select>
                </label><br>
                <button type="submit" class="submit">Next</button>
   </form>
</div>